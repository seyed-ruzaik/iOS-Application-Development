import UIKit

var name: String?

name = "swift"

//print(name!)

//if let name1 = name {
//    print(name1)
//} else {
//    print("no value")
//}

guard let name2 = name else {
    return
}
