//
//  BMI_CalculatorApp.swift
//  BMI Calculator
//
//  Created by Pubudu Mihiranga on 2023-02-10.
//

import SwiftUI

@main
struct BMI_CalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
